require(['jquery'], function( jQuery ) {

    jQuery( function( $ ) {

        /**
         * FOOTER NAVIGATION CALCULATIONS AND POSITIONING IF THE NAVBAR EXISTS
         */
        if($('.navbar-items').length>0) {
            setFooterNavigation();
            $(window).resize(setFooterNavigation);
        }


        /**
         * SETFOOTERNAVIGATION function:
         * A function that does all the calculations based on the screen resolution.
         * @returns {number} - Returns the number of items that can be placed in the NAVBAR-ITEMS-BEFORE or NAVBAR-ITEMS-AFTER
         */
        function setFooterNavigation() {

            // Get calculated sizes
            var getScreenWidth = $(window).width();
            var buttonPrev = $('.saveAnswer a.prev').width() || $('.saveAnswer a.next').width();
            var buttonNext = $('.saveAnswer a.next').width() || $('.saveAnswer a.prev').width();
            var buttonActive = $('#navbar-items-active').width() || 0;
            var margin = 100;

            // Get available space for placing items
            var avSpace = Math.round(getScreenWidth - (buttonPrev + buttonNext + buttonActive + margin));

            // Get ACTIVE index number
            var getNavStartPos = $('.navbar-items a.active').index();

            // Get number of items that can be placed within a before or after DIV
            var avItems = Math.floor((avSpace / 55)/2);
            var itemsBefore = getNavStartPos-avItems;
            var itemsAfter = getNavStartPos+1+avItems;

            // Making sure the calculation doesnt get screwed up
            if(itemsBefore<0) {
                itemsBefore=0;
            }

            $('#navbar-items-before, #navbar-items-after, #navbar-items-active').html('');
            $('#navbar-items-data a').slice(itemsBefore,getNavStartPos).clone().appendTo('#navbar-items-before');
            $('#navbar-items-data a').slice(getNavStartPos+1,itemsAfter).clone().appendTo('#navbar-items-after');
            $('#navbar-items-data a.active').clone().appendTo('#navbar-items-active');

        }

    });

});