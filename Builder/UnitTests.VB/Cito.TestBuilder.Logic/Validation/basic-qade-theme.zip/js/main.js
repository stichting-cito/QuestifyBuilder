function test() {
    alert(1);
}