require(['jquery'], function( jQuery ) {

    jQuery( function( $ ) {

        /**
         * CREATE CACHED VARIABLES AND SESSION STORAGE
         */
        var header = $('header');
        var headerHandler = $('.header-handle');
        var headerPartsHeight = $('.header-parts').height();
        var footerHeight = $('footer').height();
        var overviewWindowSpacing = 0;
        sessionStorage.setItem('overviewOpened', 'false');
        sessionStorage.setItem('dialogOpened', 'false');

        /**
         * OVERVIEW OPEN
         *
         * Unbinds click function on overview button once clicked, set sessionStorage overviewOpen to true,
         * loads overview items through Ajax, calculates the height of the overview window, animates the
         * height of the header, once done animating, rebind click function on overview button and adds
         * ACTIVE/open classes.
         */
        var overviewOpen = function() {

            $('button.ov-btn').unbind("click");
            sessionStorage.setItem('overviewOpened', 'true');
            sessionStorage.setItem('headerInitialHeight', header.height());
            var headerHeight = $(window).height() - (footerHeight + headerHandler.height() + overviewWindowSpacing);
            var overviewWindowHeight = headerHeight - (headerHandler.height() + headerPartsHeight);
            header.find('.overview').css({'height':overviewWindowHeight+'px'}).show(0);
            header.animate({ 'height': headerHeight+'px' }, 400, function() {
                $('button.ov-btn').bind("click",overviewClose);
            });
            header.find('.header-parts').addClass('ov-open');
            header.find('.ov-btn').addClass('active');

        }

        /**
         * OVERVIEW CLOSE
         *
         * Unbinds click function on overview button once clicked, set sessionStorage overviewOpened to false,
         * animates the height of the header, once done animating, rebind click function on overview
         * button and removes ACTIVE/open classes.
         */
        var overviewClose = function() {

            $('button.ov-btn').unbind("click");
            sessionStorage.setItem('overviewOpened', 'false');
            header.animate({ 'height': sessionStorage.getItem('headerInitialHeight') + 'px' }, 400, function() {
                header.find('.overview').css({ 'height':'auto' }).hide(0);
                header.find('.header-parts').removeClass('ov-open');
                header.find('.ov-btn').removeClass('active');
                $('button.ov-btn').bind("click",overviewOpen);
            });

        }

        /**
         * HEADER OPEN
         *
         * Unbinds click function on the header handler, adds open class (will add CSS transition),
         * Set sessionStorage headerOpened to true, rebind click function on header handler.
         */
        var headerOpen = function() {

            headerHandler.unbind("click");
            header.addClass('open').removeClass('closed');
            sessionStorage.setItem('headerOpened', 'true');
            headerHandler.bind("click",headerClose);

        }

        /**
         * HEADER CLOSE
         *
         * Unbinds click function on the header handler, remove sessionStorage headerOpened,
         * remove active/open classes, Checks if the overview is opened and if it is open
         * it will animate the header through jQuery, otherwise through CSS transition.
         * Once done animation rebind click function on header handler.
         */
        var headerClose = function() {

            headerHandler.unbind("click");
            sessionStorage.removeItem('headerOpened');
            header.find('.ov-btn').removeClass('active');
            header.find('.header-parts').removeClass('ov-open');
            if(sessionStorage.getItem('overviewOpened') == 'true') {
                header.stop().animate({ 'height': sessionStorage.getItem('headerInitialHeight') + 'px' }, 500, function() {
                    jQuery(this).addClass('closed').removeClass('open instant');
                    header.find('.overview').hide(0);
                    overviewClose();
                });
                $('button.ov-btn').bind("click",overviewOpen);
            } else {
                header.addClass('closed').removeClass('open instant');
            }
            headerHandler.bind("click",headerOpen);

        }

        /**
         * BIND CLICK FUNCTIONS
         *
         * set initial click binding on header handler and overview button. binds header close
         * if the header is allready open (happens when you click next/prev and the header was
         * allready open).
         */
        headerHandler.bind("click",headerOpen);
        $('button.ov-btn').bind("click",overviewOpen);
        if(sessionStorage.getItem('headerOpened')){
            header.addClass('open instant').removeClass('closed');
            headerHandler.bind("click",headerClose);
        }

        $(window).resize(function(){
            if(sessionStorage.getItem('overviewOpened') == 'true') {
                var headerHeight = $(window).height() - (footerHeight + headerHandler.height() + overviewWindowSpacing);
                var overviewWindowHeight = headerHeight - (headerHandler.height() + headerPartsHeight);
                header.css({ 'height': headerHeight+'px' });
                header.find('.overview').css({'height':overviewWindowHeight+'px'});
            }
        });

    });

})